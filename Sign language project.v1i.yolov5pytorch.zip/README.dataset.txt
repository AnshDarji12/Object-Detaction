# Sign language project > 2024-05-20 9:42pm
https://universe.roboflow.com/ansh-darji-q2ild/sign-language-project-3gs9h

Provided by a Roboflow user
License: CC BY 4.0

